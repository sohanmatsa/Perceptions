# API Documentation

Complete reference for all API endpoints.

## Base URL

```
Development: http://localhost:5000
Production: https://your-domain.com
```

## Authentication

Admin routes require JWT token in Authorization header:

```
Authorization: Bearer <your_jwt_token>
```

Get token by logging in: `POST /api/auth/login`

---

## 📋 Table of Contents

1. [Events API](#events-api)
2. [Registration API](#registration-api)
3. [Payment API](#payment-api)
4. [Admin API](#admin-api)
5. [Auth API](#auth-api)
6. [Error Responses](#error-responses)

---

## Events API

### Get All Events

```http
GET /api/events
```

**Query Parameters:**
- `category` (optional): Filter by category (technical/cultural/business/sports/arts)
- `page` (optional, default: 1): Page number
- `limit` (optional, default: 20): Items per page

**Response:**
```json
{
  "success": true,
  "count": 5,
  "total": 5,
  "pages": 1,
  "currentPage": 1,
  "data": [
    {
      "_id": "65abc...",
      "name": "Coding Marathon",
      "category": "technical",
      "teamType": "flexible",
      "minTeamSize": 2,
      "maxTeamSize": 4,
      "registrationFee": 500,
      "venue": "Computer Lab A",
      "date": "2026-04-05T00:00:00.000Z",
      "time": "9:00 AM"
    }
  ]
}
```

### Get Single Event

```http
GET /api/events/:eventId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "_id": "65abc...",
    "name": "Coding Marathon",
    "description": "24-hour hackathon...",
    "category": "technical",
    "teamType": "flexible",
    "minTeamSize": 2,
    "maxTeamSize": 4,
    "registrationFee": 500,
    "prizePool": "₹50,000",
    "venue": "Computer Lab A",
    "date": "2026-04-05T00:00:00.000Z",
    "time": "9:00 AM - 9:00 AM (24hrs)",
    "rules": ["Rule 1", "Rule 2"],
    "isActive": true,
    "maxParticipants": 100,
    "currentParticipants": 25
  }
}
```

### Get Events by Category

```http
GET /api/events/category/:category
```

**Parameters:**
- `category`: technical | cultural | business | sports | arts

**Response:** Same as Get All Events

---

## Registration API

### Create Registration

```http
POST /api/registrations
```

**Request Body:**
```json
{
  "eventId": "65abc123def456789",
  "teamMembers": [
    {
      "name": "John Doe",
      "phone": "9876543210",
      "collegeEmail": "john@college.edu",
      "collegeName": "ABC College",
      "nad": "NAD123"
    },
    {
      "name": "Jane Smith",
      "phone": "9876543211",
      "collegeEmail": "jane@college.edu",
      "collegeName": "ABC College",
      "nad": ""
    }
  ]
}
```

**Validation Rules:**
- `name`: 2-100 characters
- `phone`: 10 digits starting with 6-9
- `collegeEmail`: Valid email format
- `collegeName`: 2-200 characters
- `nad`: Optional
- Team size must match event requirements

**Response:**
```json
{
  "success": true,
  "message": "Registration created successfully",
  "data": {
    "registrationId": "EVT-001",
    "eventName": "Coding Marathon",
    "teamSize": 2,
    "amountPaid": 1000,
    "paymentStatus": "Pending",
    "primaryContact": {
      "name": "John Doe",
      "phone": "9876543210",
      "collegeEmail": "john@college.edu"
    }
  }
}
```

### Get Registration by ID

```http
GET /api/registrations/:registrationId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "registrationId": "EVT-001",
    "eventId": {...},
    "eventName": "Coding Marathon",
    "teamMembers": [...],
    "teamSize": 2,
    "amountPaid": 1000,
    "paymentStatus": "Pending",
    "createdAt": "2026-02-15T10:30:00.000Z"
  }
}
```

### Get All Registrations

```http
GET /api/registrations
```

**Query Parameters:**
- `eventId` (optional): Filter by event
- `paymentStatus` (optional): Filter by status
- `page` (optional, default: 1)
- `limit` (optional, default: 10)

**Response:** Paginated list of registrations

### Download Receipt

```http
GET /api/registrations/:registrationId/receipt
```

**Response:**
```json
{
  "success": true,
  "data": {
    "receiptUrl": "https://res.cloudinary.com/.../receipt.pdf",
    "registrationId": "EVT-001"
  }
}
```

**Error (if payment not confirmed):**
```json
{
  "success": false,
  "message": "Payment not confirmed yet. Receipt not available"
}
```

---

## Payment API

### Get Payment Instructions

```http
GET /api/payments/instructions
```

**Response:**
```json
{
  "success": true,
  "data": {
    "paymentMethods": [
      {
        "type": "UPI",
        "id": "fest@upi",
        "qrCode": "URL_TO_QR_CODE"
      },
      {
        "type": "Bank Transfer",
        "accountNumber": "1234567890",
        "ifsc": "FEST0001234",
        "accountName": "TechFusion 2026",
        "bankName": "State Bank of India"
      }
    ],
    "instructions": ["Step 1...", "Step 2..."],
    "importantNotes": ["Note 1...", "Note 2..."]
  }
}
```

### Upload Payment Screenshot

```http
POST /api/payments/upload
Content-Type: multipart/form-data
```

**Form Data:**
- `paymentScreenshot`: File (JPEG/PNG, max 5MB)
- `registrationId`: String
- `remitterName`: String (2-100 characters)
- `utrNumber`: String (5-30 characters)

**Response:**
```json
{
  "success": true,
  "message": "Payment screenshot uploaded successfully",
  "data": {
    "registrationId": "EVT-001",
    "paymentStatus": "Under Review",
    "screenshotUrl": "https://res.cloudinary.com/..."
  }
}
```

### Get Payment Status

```http
GET /api/payments/:registrationId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "registrationId": "EVT-001",
    "paymentStatus": "Under Review",
    "amountPaid": 1000,
    "utrNumber": "UTR123456789",
    "remitterName": "John Doe",
    "paymentScreenshotUrl": "https://...",
    "receiptUrl": null
  }
}
```

---

## Admin API

**All admin routes require JWT authentication**

### Login

```http
POST /api/auth/login
```

**Request:**
```json
{
  "email": "admin@fest.edu",
  "password": "securepassword"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "admin": {
      "id": "65abc...",
      "name": "Super Admin",
      "email": "admin@fest.edu",
      "role": "super_admin"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Confirm Payment

```http
POST /api/admin/confirm-payment
Authorization: Bearer <token>
```

**Request:**
```json
{
  "registrationId": "EVT-001",
  "status": "Confirmed",
  "adminNotes": "Payment verified via UPI"
}
```

**Validation:**
- `status`: Must be "Confirmed" or "Rejected"
- `adminNotes`: Optional

**Response (Confirmed):**
```json
{
  "success": true,
  "message": "Payment confirmed and receipt generated successfully",
  "data": {
    "registrationId": "EVT-001",
    "paymentStatus": "Confirmed",
    "receiptUrl": "https://res.cloudinary.com/.../receipt.pdf"
  }
}
```

**Response (Rejected):**
```json
{
  "success": true,
  "message": "Payment rejected",
  "data": {
    "registrationId": "EVT-001",
    "paymentStatus": "Rejected"
  }
}
```

### Get Pending Payments

```http
GET /api/admin/pending-payments
Authorization: Bearer <token>
```

**Query Parameters:**
- `page` (default: 1)
- `limit` (default: 20)

**Response:**
```json
{
  "success": true,
  "count": 15,
  "total": 15,
  "pages": 1,
  "currentPage": 1,
  "data": [
    {
      "registrationId": "EVT-001",
      "eventName": "Coding Marathon",
      "teamSize": 2,
      "amountPaid": 1000,
      "paymentStatus": "Under Review",
      "utrNumber": "UTR123...",
      "remitterName": "John Doe",
      "paymentScreenshotUrl": "https://...",
      "createdAt": "2026-02-15T10:30:00.000Z"
    }
  ]
}
```

### Get Statistics

```http
GET /api/admin/statistics
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "overall": {
      "total": 150,
      "pending": 20,
      "underReview": 15,
      "confirmed": 100,
      "rejected": 15,
      "totalRevenue": 75000
    },
    "eventWise": [
      {
        "_id": {
          "name": "Coding Marathon",
          "category": "technical"
        },
        "totalRegistrations": 50,
        "confirmedPayments": 40,
        "pendingPayments": 5,
        "underReview": 5,
        "totalRevenue": 25000
      }
    ]
  }
}
```

### Create Event

```http
POST /api/admin/events
Authorization: Bearer <token>
```

**Request:**
```json
{
  "name": "Coding Marathon",
  "category": "technical",
  "description": "24-hour hackathon...",
  "teamType": "flexible",
  "minTeamSize": 2,
  "maxTeamSize": 4,
  "registrationFee": 500,
  "prizePool": "₹50,000",
  "venue": "Computer Lab A",
  "date": "2026-04-05",
  "time": "9:00 AM - 9:00 AM (24hrs)",
  "rules": ["Rule 1", "Rule 2"],
  "maxParticipants": 100
}
```

**Response:**
```json
{
  "success": true,
  "message": "Event created successfully",
  "data": { /* event object */ }
}
```

### Update Event

```http
PUT /api/admin/events/:eventId
Authorization: Bearer <token>
```

### Delete Event

```http
DELETE /api/admin/events/:eventId
Authorization: Bearer <token>
```

**Note:** Cannot delete events with existing registrations

### Get All Registrations (Admin)

```http
GET /api/admin/registrations
Authorization: Bearer <token>
```

**Query Parameters:**
- `eventId` (optional)
- `paymentStatus` (optional)
- `search` (optional): Search by registration ID, email, or name
- `page` (default: 1)
- `limit` (default: 20)

---

## Auth API

### Setup First Admin

```http
POST /api/auth/setup
```

**Request:**
```json
{
  "name": "Super Admin",
  "email": "admin@fest.edu",
  "password": "securepassword123"
}
```

**Note:** Only works if no admin exists in database

### Get Current Admin

```http
GET /api/auth/me
Authorization: Bearer <token>
```

### Logout

```http
POST /api/auth/logout
Authorization: Bearer <token>
```

---

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Validation error message"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Not authorized to access this route"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Resource not found"
}
```

### 500 Server Error
```json
{
  "success": false,
  "message": "Server error message"
}
```

---

## Rate Limiting

- **Limit:** 100 requests per 15 minutes per IP
- **Response when exceeded:**
```json
{
  "message": "Too many requests from this IP, please try again later."
}
```

---

## File Upload Limits

- **Max file size:** 5MB
- **Allowed types:** JPEG, PNG, JPG
- **Storage:** Cloudinary (URLs stored in MongoDB)

---

**For more examples, see the Postman collection or test the API at `/health` endpoint.**
