import { v2 as cloudinary } from 'cloudinary';
import dotenv from 'dotenv';

// Load env variables if not already loaded
if (!process.env.CLOUDINARY_CLOUD_NAME) {
  dotenv.config();
}

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

// Log configuration status (only in development)
if (process.env.NODE_ENV === 'development') {
  const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
  if (cloudName) {
    console.log('✅ Cloudinary configured:', cloudName);
  } else {
    console.error('⚠️  Cloudinary credentials not loaded from .env!');
  }
}

export default cloudinary;