import Registration from '../models/Registration.js';
import cloudinaryService from '../services/cloudinary.service.js';
import pdfService from '../services/pdf.service.js';
import { asyncHandler, AppError } from '../middleware/error.js';

/**
 * @desc    Upload payment screenshot and auto-generate receipt (async)
 * @route   POST /api/payments/upload
 * @access  Public
 */
export const uploadPayment = asyncHandler(async (req, res, next) => {
  const { registrationId, remitterName, utrNumber } = req.body;

  // Validate input
  if (!registrationId || !remitterName || !utrNumber) {
    return next(new AppError('Registration ID, remitter name, and UTR number are required', 400));
  }

  // Check if file was uploaded
  if (!req.file) {
    return next(new AppError('Please upload a payment screenshot', 400));
  }

  // Find registration
  const registration = await Registration.findOne({ registrationId });

  if (!registration) {
    return next(new AppError('Registration not found', 404));
  }

  if (registration.paymentStatus === 'Confirmed') {
    return next(new AppError('Payment already confirmed', 400));
  }

  console.log(`📤 Uploading payment screenshot for ${registrationId}...`);

  try {
    // Upload payment screenshot to Cloudinary
    const screenshotUrl = await cloudinaryService.uploadPaymentScreenshot(
      req.file.path,
      registrationId
    );

    console.log(`✅ Payment screenshot uploaded: ${screenshotUrl}`);

    // Update registration with payment details and AUTO-CONFIRM
    registration.paymentScreenshotUrl = screenshotUrl;
    registration.remitterName = remitterName;
    registration.utrNumber = utrNumber;
    registration.paymentStatus = 'Confirmed'; // AUTO-CONFIRM after upload
    registration.confirmedAt = new Date();

    await registration.save();

    console.log(`✅ Payment auto-confirmed for ${registrationId}`);

    // Delete local uploaded file
    await cloudinaryService.deleteLocalFile(req.file.path);

    // Generate receipt ASYNCHRONOUSLY (don't wait for it)
    // This prevents blocking the response
    generateReceiptAsync(registration, registrationId);

    // Respond immediately (don't wait for PDF generation)
    res.status(200).json({
      success: true,
      message: 'Payment uploaded and confirmed! Your receipt is being generated.',
      data: {
        registrationId: registration.registrationId,
        paymentStatus: registration.paymentStatus,
        screenshotUrl: registration.paymentScreenshotUrl,
        confirmedAt: registration.confirmedAt,
        // Don't include receiptUrl yet - it's being generated
      },
    });
  } catch (error) {
    // Clean up uploaded file if error occurs
    if (req.file && req.file.path) {
      await cloudinaryService.deleteLocalFile(req.file.path);
    }
    throw error;
  }
});

/**
 * Generate receipt asynchronously without blocking response
 * This runs in the background after payment confirmation
 */
async function generateReceiptAsync(registration, registrationId) {
  try {
    console.log('🎫 Generating receipt for:', registrationId);
    
    // Generate PDF as base64
    const base64PDF = await pdfService.generateReceiptBase64(registration);
    
    // Update registration with base64 PDF
    const updatedReg = await Registration.findOne({ registrationId });
    if (updatedReg) {
      updatedReg.receiptPDF = base64PDF;
      updatedReg.receiptUrl = `/api/receipts/${registrationId}`; // Backend URL
      await updatedReg.save();
      console.log('✅ Receipt saved to database!');
    }
    
  } catch (error) {
    console.error('❌ Error generating receipt:', error);
  }
}

/**
 * @desc    Get payment status
 * @route   GET /api/payments/:registrationId
 * @access  Public
 */
export const getPaymentStatus = asyncHandler(async (req, res, next) => {
  const { registrationId } = req.params;

  const registration = await Registration.findOne({ registrationId });

  if (!registration) {
    return next(new AppError('Registration not found', 404));
  }

  res.status(200).json({
    success: true,
    data: {
      registrationId: registration.registrationId,
      paymentStatus: registration.paymentStatus,
      paymentScreenshotUrl: registration.paymentScreenshotUrl,
      receiptUrl: registration.receiptUrl,
      remitterName: registration.remitterName,
      utrNumber: registration.utrNumber,
      confirmedAt: registration.confirmedAt,
    },
  });
});

/**
 * @desc    Get payment instructions
 * @route   GET /api/payments/instructions
 * @access  Public
 */
export const getPaymentInstructions = asyncHandler(async (req, res, next) => {
  const paymentMethods = [
    {
      type: 'UPI',
      id: process.env.UPI_ID || 'fest@upi',
      name: 'UPI Payment',
      icon: '💳',
    },
    {
      type: 'Bank Transfer',
      accountNumber: process.env.BANK_ACCOUNT_NUMBER || '1234567890',
      ifsc: process.env.BANK_IFSC || 'BANK0001234',
      name: 'Bank Transfer',
      icon: '🏦',
    },
  ];

  res.status(200).json({
    success: true,
    data: {
      paymentMethods,
      instructions: [
        'Complete the payment using any of the methods above',
        'Take a screenshot of the payment confirmation',
        'Upload the screenshot along with transaction details',
        'Your receipt will be generated automatically within a few seconds',
      ],
    },
  });
});

/**
 * @desc    Regenerate receipt (admin only - optional)
 * @route   POST /api/payments/:registrationId/regenerate-receipt
 * @access  Admin
 */
export const regenerateReceipt = asyncHandler(async (req, res, next) => {
  const { registrationId } = req.params;

  const registration = await Registration.findOne({ registrationId });

  if (!registration) {
    return next(new AppError('Registration not found', 404));
  }

  if (registration.paymentStatus !== 'Confirmed') {
    return next(new AppError('Payment not confirmed. Cannot generate receipt.', 400));
  }

  console.log(`🔄 Regenerating receipt for ${registrationId}...`);

  try {
    // Generate PDF receipt
    const pdfPath = await pdfService.generateReceipt(registration);
    console.log(`✅ PDF generated: ${pdfPath}`);

    // Upload receipt to Cloudinary
    const receiptUrl = await cloudinaryService.uploadReceipt(pdfPath, registrationId);
    console.log(`✅ Receipt uploaded: ${receiptUrl}`);

    // Clean up local file
    await cloudinaryService.deleteLocalFile(pdfPath);

    // Update registration
    registration.receiptUrl = receiptUrl;
    await registration.save();

    res.status(200).json({
      success: true,
      message: 'Receipt regenerated successfully',
      data: {
        registrationId: registration.registrationId,
        receiptUrl: registration.receiptUrl,
      },
    });
  } catch (error) {
    console.error('Error regenerating receipt:', error);
    return next(new AppError('Failed to regenerate receipt', 500));
  }
});