import Event from '../models/Event.js';
import { asyncHandler, AppError } from '../middleware/error.js';

/**
 * @desc    Get all active events
 * @route   GET /api/events
 * @access  Public
 */
export const getAllEvents = asyncHandler(async (req, res, next) => {
  const { category, page = 1, limit = 20 } = req.query;
  const skip = (page - 1) * limit;

  const query = { isActive: true };
  
  if (category) {
    query.category = category;
  }

  const events = await Event.find(query)
    .sort({ date: 1 })
    .skip(skip)
    .limit(parseInt(limit));

  const total = await Event.countDocuments(query);

  res.status(200).json({
    success: true,
    count: events.length,
    total,
    pages: Math.ceil(total / limit),
    currentPage: parseInt(page),
    data: events,
  });
});

/**
 * @desc    Get single event
 * @route   GET /api/events/:eventId
 * @access  Public
 */
export const getEvent = asyncHandler(async (req, res, next) => {
  const { eventId } = req.params;

  const event = await Event.findById(eventId);

  if (!event) {
    return next(new AppError('Event not found', 404));
  }

  res.status(200).json({
    success: true,
    data: event,
  });
});

/**
 * @desc    Get events by category
 * @route   GET /api/events/category/:category
 * @access  Public
 */
export const getEventsByCategory = asyncHandler(async (req, res, next) => {
  const { category } = req.params;

  const events = await Event.find({ 
    category, 
    isActive: true 
  }).sort({ date: 1 });

  res.status(200).json({
    success: true,
    count: events.length,
    data: events,
  });
});
