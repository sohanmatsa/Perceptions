import Registration from '../models/Registration.js';
import Event from '../models/Event.js';
import pdfService from '../services/pdf.service.js';
import cloudinaryService from '../services/cloudinary.service.js';
import registrationService from '../services/registration.service.js';
import { paymentConfirmationValidation, eventValidation } from '../utils/validation.js';
import { asyncHandler, AppError } from '../middleware/error.js';

/**
 * @desc    Confirm or reject payment
 * @route   POST /api/admin/confirm-payment
 * @access  Private (Admin only)
 */
export const confirmPayment = asyncHandler(async (req, res) => {
  const { registrationId, status, adminNotes } = req.body;

  // Validate input
  if (!registrationId || !status) {
    throw new AppError('Registration ID and status are required', 400);
  }

  if (!['Confirmed', 'Rejected'].includes(status)) {
    throw new AppError('Status must be either Confirmed or Rejected', 400);
  }

  // Find registration
  const registration = await Registration.findOne({ registrationId });

  if (!registration) {
    throw new AppError('Registration not found', 404);
  }

  if (registration.paymentStatus === 'Confirmed') {
    throw new AppError('Payment already confirmed', 400);
  }

  console.log(`Processing payment ${status} for ${registrationId}...`);

  let receiptUrl = null;

  // If confirming payment, generate and upload receipt
  if (status === 'Confirmed') {
    try {
      console.log('1️⃣ Generating PDF receipt...');
      // Generate PDF receipt
      const pdfPath = await pdfService.generateReceipt(registration);
      console.log('✅ PDF generated at:', pdfPath);

      console.log('2️⃣ Uploading to Cloudinary...');
      // Upload to Cloudinary
      receiptUrl = await cloudinaryService.uploadReceipt(pdfPath, registrationId);
      console.log('✅ Uploaded to Cloudinary:', receiptUrl);

      console.log('3️⃣ Cleaning up local file...');
      // Delete local file
      await cloudinaryService.deleteLocalFile(pdfPath);
      console.log('✅ Local file deleted');
    } catch (error) {
      console.error('❌ Error generating/uploading receipt:', error);
      throw new AppError('Failed to generate receipt: ' + error.message, 500);
    }
  }

  // Update registration
  registration.paymentStatus = status;
  registration.receiptUrl = receiptUrl;
  registration.adminNotes = adminNotes;
  registration.confirmedBy = req.admin._id;
  registration.confirmedAt = new Date();

  await registration.save();

  console.log('✅ Payment confirmed successfully!');

  res.status(200).json({
    success: true,
    message: `Payment ${status.toLowerCase()} successfully`,
    data: {
      registrationId: registration.registrationId,
      paymentStatus: registration.paymentStatus,
      receiptUrl: registration.receiptUrl,
      confirmedAt: registration.confirmedAt,
    },
  });
});

/**
 * @desc    Get all pending payments
 * @route   GET /api/admin/pending-payments
 */
export const getPendingPayments = asyncHandler(async (req, res) => {
  const payments = await Registration.find({ paymentStatus: 'Under Review' })
    .populate('eventId', 'name category')
    .sort({ createdAt: -1 });

  res.status(200).json({
    success: true,
    data: payments,
  });
});

/**
 * @desc    Get registration statistics
 * @route   GET /api/admin/statistics
 */
export const getStatistics = asyncHandler(async (req, res) => {
  const stats = await registrationService.getStatistics();

  const eventStats = await Registration.aggregate([
    {
      $group: {
        _id: '$eventId',
        totalRegistrations: { $sum: 1 },
        confirmedPayments: {
          $sum: { $cond: [{ $eq: ['$paymentStatus', 'Confirmed'] }, 1, 0] },
        },
        underReview: {
          $sum: { $cond: [{ $eq: ['$paymentStatus', 'Under Review'] }, 1, 0] },
        },
        totalRevenue: {
          $sum: { $cond: [{ $eq: ['$paymentStatus', 'Confirmed'] }, '$amountPaid', 0] },
        },
      },
    },
  ]);

  const populatedEventStats = await Event.populate(eventStats, {
    path: '_id',
    select: 'name category',
  });

  res.status(200).json({
    success: true,
    data: {
      overall: stats,
      eventWise: populatedEventStats,
    },
  });
});

/**
 * @desc    Create event
 * @route   POST /api/admin/events
 * @access  Private (Admin only)
 */
export const createEvent = asyncHandler(async (req, res, next) => {
  // Validate basic fields (ignore file here)
  const { error } = eventValidation.validate(req.body);
  if (error) {
    return next(new AppError(error.details[0].message, 400));
  }

  const {
    name,
    description,
    category,
    date,
    time,
    venue,
    registrationFee,
    prizePool,
    maxParticipants,
    teamType,
    minTeamSize,
    maxTeamSize,
    rules,
    icon,

    // Coordinators
    primaryCoordinatorName,
    primaryCoordinatorPhone,
    secondaryCoordinatorName,
    secondaryCoordinatorPhone,
    coordinatorEmail,
  } = req.body;

  // Parse rules safely
  let parsedRules = [];
  if (rules) {
    try {
      parsedRules = typeof rules === 'string' ? JSON.parse(rules) : rules;
    } catch (err) {
      return next(new AppError('Invalid rules format', 400));
    }
  }

  let logoUrl = null;

  // ========= LOGO UPLOAD =========
  if (req.file) {
    try {
      console.log('📤 Uploading event logo...');
      logoUrl = await cloudinaryService.uploadEventLogo(
        req.file.path,
        name
      );
      await cloudinaryService.deleteLocalFile(req.file.path);
    } catch (err) {
      console.error('❌ Logo upload failed:', err.message);
      // do NOT block event creation
      logoUrl = null;
    }
  }
  // ===============================

  const event = await Event.create({
    name,
    description,
    category,
    date,
    time,
    venue,
    registrationFee,
    prizePool,
    maxParticipants: maxParticipants || null,
    teamType,
    minTeamSize,
    maxTeamSize,
    rules: parsedRules,
    icon,
    logoUrl,

    // Coordinators
    primaryCoordinatorName,
    primaryCoordinatorPhone,
    secondaryCoordinatorName: secondaryCoordinatorName || null,
    secondaryCoordinatorPhone: secondaryCoordinatorPhone || null,
    coordinatorEmail,

    createdBy: req.admin._id,
  });

  res.status(201).json({
    success: true,
    message: 'Event created successfully',
    data: event,
  });
});


/**
 * @desc    Update event
 * @route   PUT /api/admin/events/:eventId
 */
export const updateEvent = asyncHandler(async (req, res, next) => {
  const event = await Event.findByIdAndUpdate(req.params.eventId, req.body, {
    new: true,
    runValidators: true,
  });

  if (!event) return next(new AppError('Event not found', 404));

  res.status(200).json({
    success: true,
    data: event,
  });
});

/**
 * @desc    Delete event
 * @route   DELETE /api/admin/events/:eventId
 */
export const deleteEvent = asyncHandler(async (req, res, next) => {
  const count = await Registration.countDocuments({ eventId: req.params.eventId });
  if (count > 0) {
    return next(new AppError('Cannot delete event with registrations', 400));
  }

  const event = await Event.findByIdAndDelete(req.params.eventId);
  if (!event) return next(new AppError('Event not found', 404));

  res.status(200).json({
    success: true,
    message: 'Event deleted successfully',
  });
});

/**
 * @desc    Get all registrations
 * @route   GET /api/admin/registrations
 */
export const getAllRegistrationsAdmin = asyncHandler(async (req, res) => {
  const registrations = await Registration.find()
    .populate('eventId', 'name category')
    .populate('confirmedBy', 'name email')
    .sort({ createdAt: -1 });

  res.status(200).json({
    success: true,
    data: registrations,
  });
});

/**
 * @desc    Delete registration
 * @route   DELETE /api/admin/registrations/:registrationId
 * @access  Private (Admin only)
 */
export const deleteRegistration = asyncHandler(async (req, res) => {
  const { registrationId } = req.params;

  // Find registration
  const registration = await Registration.findOne({ registrationId });

  if (!registration) {
    throw new AppError('Registration not found', 404);
  }

  // Delete payment screenshot from Cloudinary if exists
  if (registration.paymentScreenshotUrl) {
    try {
      const publicId = registration.paymentScreenshotUrl.split('/').slice(-2).join('/').split('.')[0];
      await cloudinaryService.deleteFile(`fest/payments/${publicId}`, 'image');
    } catch (error) {
      console.log('Error deleting payment screenshot:', error.message);
    }
  }

  // Delete receipt PDF from Cloudinary if exists
  if (registration.receiptUrl) {
    try {
      const publicId = registration.receiptUrl.split('/').slice(-2).join('/').split('.')[0];
      await cloudinaryService.deleteFile(`fest/receipts/${publicId}`, 'raw');
    } catch (error) {
      console.log('Error deleting receipt:', error.message);
    }
  }

  // Update event participant count
  const event = await Event.findById(registration.eventId);
  if (event) {
    event.currentParticipants = Math.max(0, event.currentParticipants - registration.teamSize);
    await event.save();
  }

  // Delete registration
  await Registration.findOneAndDelete({ registrationId });

  res.status(200).json({
    success: true,
    message: 'Registration deleted successfully',
    data: {
      registrationId,
      deletedAt: new Date(),
    },
  });
});