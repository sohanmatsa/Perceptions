import Admin from '../models/Admin.js';
import { generateToken } from '../middleware/auth.js';
import { adminLoginValidation } from '../utils/validation.js';
import { asyncHandler, AppError } from '../middleware/error.js';

/**
 * @desc    Admin login
 * @route   POST /api/auth/login
 * @access  Public
 */
export const login = asyncHandler(async (req, res, next) => {
  // Validate request body
  const { error, value } = adminLoginValidation.validate(req.body);
  
  if (error) {
    return next(new AppError(error.details[0].message, 400));
  }

  const { email, password } = value;

  // Find admin with password field
  const admin = await Admin.findOne({ email }).select('+password');

  if (!admin) {
    return next(new AppError('Invalid credentials', 401));
  }

  // Check if admin is active
  if (!admin.isActive) {
    return next(new AppError('Your account has been deactivated', 401));
  }

  // Check password
  const isPasswordMatch = await admin.comparePassword(password);

  if (!isPasswordMatch) {
    return next(new AppError('Invalid credentials', 401));
  }

  // Update last login
  admin.lastLogin = new Date();
  await admin.save();

  // Generate token
  const token = generateToken(admin._id);

  res.status(200).json({
    success: true,
    message: 'Login successful',
    data: {
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
      },
      token,
    },
  });
});

/**
 * @desc    Get current admin profile
 * @route   GET /api/auth/me
 * @access  Private
 */
export const getMe = asyncHandler(async (req, res, next) => {
  const admin = await Admin.findById(req.admin._id);

  res.status(200).json({
    success: true,
    data: admin,
  });
});

/**
 * @desc    Create first admin (for setup)
 * @route   POST /api/auth/setup
 * @access  Public (only if no admin exists)
 */
export const setupAdmin = asyncHandler(async (req, res, next) => {
  // Check if any admin exists
  const adminExists = await Admin.countDocuments();

  if (adminExists > 0) {
    return next(new AppError('Admin already exists. Use login to access.', 400));
  }

  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return next(new AppError('Please provide name, email, and password', 400));
  }

  // Create super admin
  const admin = await Admin.create({
    name,
    email,
    password,
    role: 'super_admin',
  });

  // Generate token
  const token = generateToken(admin._id);

  res.status(201).json({
    success: true,
    message: 'Super admin created successfully',
    data: {
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
      },
      token,
    },
  });
});

/**
 * @desc    Logout admin
 * @route   POST /api/auth/logout
 * @access  Private
 */
export const logout = asyncHandler(async (req, res, next) => {
  res.status(200).json({
    success: true,
    message: 'Logout successful',
  });
});
