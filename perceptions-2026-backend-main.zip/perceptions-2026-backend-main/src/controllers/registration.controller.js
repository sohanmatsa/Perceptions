import Registration from '../models/Registration.js';
import Event from '../models/Event.js';
import registrationService from '../services/registration.service.js';
import { registrationValidation } from '../utils/validation.js';
import { asyncHandler, AppError } from '../middleware/error.js';

/**
 * @desc    Create new registration (payment upload still required)
 * @route   POST /api/registrations
 * @access  Public
 */
export const createRegistration = asyncHandler(async (req, res, next) => {
  const { error, value } = registrationValidation.validate(req.body);

  if (error) {
    return next(new AppError(error.details[0].message, 400));
  }

  const { eventId, teamMembers } = value;

  const event = await Event.findById(eventId);

  if (!event) {
    return next(new AppError('Event not found', 404));
  }

  if (!event.isActive) {
    return next(new AppError('Event registration is closed', 400));
  }

  const teamSize = teamMembers.length;

  if (!registrationService.validateTeamSize(event, teamSize)) {
    return next(
      new AppError(
        `Invalid team size. Event requires ${
          event.teamType === 'solo'
            ? '1 participant'
            : event.teamType === 'fixed'
            ? `exactly ${event.minTeamSize} members`
            : `${event.minTeamSize}-${event.maxTeamSize} members`
        }`,
        400
      )
    );
  }

  // ✅ Check available team slots
  if (!registrationService.hasAvailableSlots(event)) {
    return next(new AppError('Event is full. No more slots available', 400));
  }

  const existingRegistration = await Registration.findOne({
    eventId,
    'teamMembers.collegeEmail': {
      $in: teamMembers.map((m) => m.collegeEmail.toLowerCase()),
    },
  });

  if (existingRegistration) {
    return next(
      new AppError(
        'One or more team members are already registered for this event',
        400
      )
    );
  }

  const registrationId =
    await registrationService.generateRegistrationId(eventId);

  const registration = await Registration.create({
    registrationId,
    eventId: event._id,
    eventName: event.name,
    teamMembers,
    teamSize,
    amountPaid: event.registrationFee,
    paymentStatus: 'Pending',
  });

  // ✅ ONLY increment by 1 team
  await registrationService.incrementParticipantCount(eventId);

  res.status(201).json({
    success: true,
    message: 'Registration created successfully. Please proceed to payment.',
    data: {
      registrationId: registration.registrationId,
      eventName: registration.eventName,
      teamSize: registration.teamSize,
      amountPaid: registration.amountPaid,
      paymentStatus: registration.paymentStatus,
    },
  });
});

/**
 * @desc    Get registration by ID
 * @route   GET /api/registrations/:registrationId
 * @access  Public
 */
export const getRegistration = asyncHandler(async (req, res, next) => {
  const { registrationId } = req.params;

  const registration = await Registration.findOne({ registrationId }).populate('eventId', 'name category date time venue');

  if (!registration) {
    return next(new AppError('Registration not found', 404));
  }

  res.status(200).json({
    success: true,
    data: registration,
  });
});

/**
 * @desc    Get all registrations (with filters)
 * @route   GET /api/registrations
 * @access  Public (limited info) / Admin (full info)
 */
export const getAllRegistrations = asyncHandler(async (req, res, next) => {
  const { eventId, paymentStatus, page = 1, limit = 10 } = req.query;

  const query = {};
  
  if (eventId) query.eventId = eventId;
  if (paymentStatus) query.paymentStatus = paymentStatus;

  const skip = (page - 1) * limit;

  const registrations = await Registration.find(query)
    .populate('eventId', 'name category')
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(parseInt(limit));

  const total = await Registration.countDocuments(query);

  res.status(200).json({
    success: true,
    count: registrations.length,
    total,
    pages: Math.ceil(total / limit),
    currentPage: parseInt(page),
    data: registrations,
  });
});

/**
 * @desc    Download receipt
 * @route   GET /api/registrations/:registrationId/receipt
 * @access  Public (only if payment confirmed)
 */
export const downloadReceipt = asyncHandler(async (req, res, next) => {
  const { registrationId } = req.params;

  const registration = await Registration.findOne({ registrationId });

  if (!registration) {
    return next(new AppError('Registration not found', 404));
  }

  if (registration.paymentStatus !== 'Confirmed') {
    return next(new AppError('Payment not confirmed yet. Receipt not available', 400));
  }

  if (!registration.receiptUrl) {
    return next(new AppError('Receipt not generated yet', 404));
  }

  res.status(200).json({
    success: true,
    data: {
      receiptUrl: registration.receiptUrl,
      registrationId: registration.registrationId,
    },
  });
});