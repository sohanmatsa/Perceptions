import PDFDocument from 'pdfkit';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import Event from '../models/Event.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class PDFService {
  /**
   * Generate registration receipt PDF with event-specific coordinator contacts
   */
  async generateReceipt(registration) {
    try {
      console.log('📄 Starting PDF generation for:', registration.registrationId);

      // ========== FETCH EVENT DETAILS FOR COORDINATORS ==========
      const event = await Event.findById(registration.eventId);
      if (!event) {
        throw new Error('Event not found for receipt generation');
      }
      console.log('✅ Event details fetched:', event.name);
      // ==========================================================

      // Ensure uploads directory exists
      const uploadsDir = path.join(__dirname, '../../uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      const filename = `receipt_${registration.registrationId}_${Date.now()}.pdf`;
      const filepath = path.join(uploadsDir, filename);

      console.log('📝 Creating PDF at:', filepath);

      return new Promise((resolve, reject) => {
        try {
          const doc = new PDFDocument({
            size: 'A4',
            margin: 50,
            bufferPages: true,
            autoFirstPage: true,
          });

          const writeStream = fs.createWriteStream(filepath);
          doc.pipe(writeStream);

          let currentY = 50;

          // ====================
          // HEADER WITH LOGO
          // ====================
          
          // Logo/Title
          const logoText = 'SANGAMA';
          doc.fontSize(32)
             .fillColor('#FF6B35')
             .text(logoText, 50, currentY, {
               align: 'center',
               width: 495
             });

          currentY += 45;

          // Event name
          doc.fontSize(24)
             .fillColor('#F7931E')
             .text('PERCEPTIONS 2026', 50, currentY, {
               align: 'center',
               width: 495
             });

          currentY += 30;

          doc.fontSize(12)
             .fillColor('#666666')
             .text('Official Registration Receipt', 50, currentY, {
               align: 'center',
               width: 495
             });

          currentY += 40;

          // Registration ID Box
          doc.rect(150, currentY, 295, 50)
             .fillAndStroke('#FFF8F0', '#FF6B35');

          doc.fontSize(10)
             .fillColor('#666666')
             .text('Registration ID', 50, currentY + 10, {
               align: 'center',
               width: 495
             });

          doc.fontSize(18)
             .fillColor('#FF6B35')
             .text(registration.registrationId, 50, currentY + 28, {
               align: 'center',
               width: 495
             });

          currentY += 70;

          // Line separator
          doc.moveTo(50, currentY)
             .lineTo(545, currentY)
             .strokeColor('#FF6B35')
             .lineWidth(2)
             .stroke();

          currentY += 20;

          // ====================
          // EVENT DETAILS
          // ====================
          doc.fontSize(14)
             .fillColor('#FF6B35')
             .text('EVENT DETAILS', 50, currentY);

          currentY += 25;

          // Event Name
          doc.fontSize(9)
             .fillColor('#666666')
             .text('Event Name:', 50, currentY);
          doc.fontSize(11)
             .fillColor('#000000')
             .text(registration.eventName, 150, currentY);

          currentY += 22;

          // Team Size
          doc.fontSize(9)
             .fillColor('#666666')
             .text('Team Size:', 50, currentY);
          doc.fontSize(10)
             .fillColor('#000000')
             .text(`${registration.teamSize} ${registration.teamSize === 1 ? 'Person' : 'People'}`, 150, currentY);

          currentY += 22;

          // Registration Fee
          doc.fontSize(9)
             .fillColor('#666666')
             .text('Registration Fee:', 50, currentY);
          doc.fontSize(12)
             .fillColor('#FF6B35')
             .text(`₹ ${registration.amountPaid}`, 150, currentY);

          currentY += 22;

          // Payment Status
          doc.fontSize(9)
             .fillColor('#666666')
             .text('Payment Status:', 50, currentY);
          doc.fontSize(10)
             .fillColor('#2ECC71')
             .text('CONFIRMED ✓', 150, currentY);

          currentY += 35;

          // ====================
          // PAYMENT DETAILS
          // ====================
          if (registration.utrNumber || registration.remitterName) {
            doc.fontSize(14)
               .fillColor('#FF6B35')
               .text('PAYMENT DETAILS', 50, currentY);

            currentY += 25;

            if (registration.remitterName) {
              doc.fontSize(9)
                 .fillColor('#666666')
                 .text('Remitter Name:', 50, currentY);
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text(registration.remitterName, 150, currentY);
              currentY += 20;
            }

            if (registration.utrNumber) {
              doc.fontSize(9)
                 .fillColor('#666666')
                 .text('UTR Number:', 50, currentY);
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text(registration.utrNumber, 150, currentY);
              currentY += 20;
            }

            if (registration.confirmedAt) {
              doc.fontSize(9)
                 .fillColor('#666666')
                 .text('Payment Date:', 50, currentY);
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text(new Date(registration.confirmedAt).toLocaleDateString('en-IN'), 150, currentY);
              currentY += 20;
            }

            currentY += 15;
          }

          // ====================
          // TEAM MEMBERS
          // ====================
          doc.fontSize(14)
             .fillColor('#FF6B35')
             .text('TEAM MEMBERS', 50, currentY);

          currentY += 25;

          registration.teamMembers.forEach((member, index) => {
            if (currentY > 680) {
              doc.addPage();
              currentY = 50;
            }

            doc.fontSize(10)
               .fillColor('#FF6B35')
               .text(`${index + 1}.`, 50, currentY);

            doc.fontSize(11)
               .fillColor('#000000')
               .text(member.name, 70, currentY);

            if (index === 0) {
              doc.fontSize(8)
                 .fillColor('#FF6B35')
                 .text('(Team Lead)', 70 + doc.widthOfString(member.name) + 5, currentY + 2);
            }

            currentY += 20;

            doc.fontSize(9)
               .fillColor('#666666')
               .text(`Email: ${member.collegeEmail}`, 70, currentY);
            currentY += 16;

            doc.text(`Phone: ${member.phone}`, 70, currentY);
            currentY += 16;

            doc.text(`College: ${member.collegeName}`, 70, currentY);
            currentY += 16;

            if (member.rollNo || member.nad) {
              doc.text(`Roll No.: ${member.rollNo || member.nad}`, 70, currentY);
              currentY += 16;
            }

            currentY += 12;
          });

          currentY += 10;

          // ====================
          // IMPORTANT NOTES
          // ====================
          if (currentY > 620) {
            doc.addPage();
            currentY = 50;
          }

          doc.fontSize(14)
             .fillColor('#FF6B35')
             .text('IMPORTANT NOTES', 50, currentY);

          currentY += 25;

          const notes = [
            'Bring this receipt and a valid ID to the event',
            'Arrive 15 minutes early for check-in',
            'Computer-generated receipt, no signature required',
            'Contact event coordinator for any queries',
          ];

          notes.forEach((note) => {
            doc.fontSize(9)
               .fillColor('#666666')
               .text(`• ${note}`, 50, currentY);
            currentY += 18;
          });

          currentY += 10;

          // ========== EVENT-SPECIFIC COORDINATOR CONTACTS ==========
          doc.fontSize(14)
             .fillColor('#FF6B35')
             .text('EVENT COORDINATOR', 50, currentY);

          currentY += 25;

          // Use event-specific coordinators
          if (event.coordinators && event.coordinators.length > 0) {
            // Multiple coordinators approach
            event.coordinators.forEach((coordinator) => {
              if (currentY > 720) {
                doc.addPage();
                currentY = 50;
              }

              doc.fontSize(10)
                 .fillColor('#000000')
                 .text(`${coordinator.name} (${coordinator.role}):`, 50, currentY);
              
              doc.fontSize(10)
                 .fillColor('#FF6B35')
                 .text(coordinator.phone, 250, currentY);
              
              currentY += 20;
            });

            // Add email if available
            const emailCoordinator = event.coordinators.find(c => c.email);
            if (emailCoordinator) {
              doc.fontSize(9)
                 .fillColor('#666666')
                 .text(`Email: ${emailCoordinator.email}`, 50, currentY);
              currentY += 20;
            }
          } else if (event.primaryCoordinatorName || event.primaryCoordinatorPhone) {
            // Simple coordinator fields approach
            if (event.primaryCoordinatorName && event.primaryCoordinatorPhone) {
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text('Event Head:', 50, currentY);
              
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text(event.primaryCoordinatorName, 150, currentY);

              doc.fontSize(10)
                 .fillColor('#FF6B35')
                 .text(`+91 ${event.primaryCoordinatorPhone}`, 300, currentY);
              
              currentY += 22;
            }

            if (event.secondaryCoordinatorName && event.secondaryCoordinatorPhone) {
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text('Coordinator:', 50, currentY);
              
              doc.fontSize(10)
                 .fillColor('#000000')
                 .text(event.secondaryCoordinatorName, 150, currentY);

              doc.fontSize(10)
                 .fillColor('#FF6B35')
                 .text(`+91 ${event.secondaryCoordinatorPhone}`, 300, currentY);
              
              currentY += 22;
            }

            if (event.coordinatorEmail) {
              doc.fontSize(9)
                 .fillColor('#666666')
                 .text(`Email: ${event.coordinatorEmail}`, 50, currentY);
              currentY += 20;
            }
          } else {
            // Fallback to default contacts
            doc.fontSize(9)
               .fillColor('#666666')
               .text('Contact: events@perceptions.co.in', 50, currentY);
            currentY += 20;
          }
          // ==========================================================

          // ====================
          // FOOTER
          // ====================
          const pageCount = doc.bufferedPageRange().count;
          for (let i = 0; i < pageCount; i++) {
            doc.switchToPage(i);
            
            const footerY = 750;
            
            doc.moveTo(50, footerY)
               .lineTo(545, footerY)
               .strokeColor('#CCCCCC')
               .lineWidth(1)
               .stroke();

            doc.fontSize(8)
               .fillColor('#999999')
               .text(`Generated: ${new Date().toLocaleDateString('en-IN')}`, 50, footerY + 10, {
                 width: 200
               });

            doc.text('PERCEPTIONS 2026 | SANGAMA', 50, footerY + 10, {
               align: 'right',
               width: 495
            });

            doc.text(`Page ${i + 1} of ${pageCount}`, 50, footerY + 22, {
               align: 'center',
               width: 495
            });
          }

          doc.end();

          writeStream.on('finish', () => {
            const stats = fs.statSync(filepath);
            console.log('✅ PDF generated successfully');
            console.log('📏 File size:', stats.size, 'bytes');
            
            if (stats.size === 0) {
              reject(new Error('Generated PDF is empty'));
            } else {
              resolve(filepath);
            }
          });

          writeStream.on('error', (error) => {
            console.error('❌ Error writing PDF:', error);
            reject(error);
          });

          setTimeout(() => {
            if (!writeStream.destroyed) {
              writeStream.destroy();
              reject(new Error('PDF generation timeout'));
            }
          }, 10000);

        } catch (error) {
          console.error('❌ Error creating PDF:', error);
          reject(error);
        }
      });
    } catch (error) {
      console.error('❌ Error in generateReceipt:', error);
      throw error;
    }
  }

  /**
   * Generate PDF as base64 for database storage
   */
  async generateReceiptBase64(registration) {
    try {
      const filepath = await this.generateReceipt(registration);
      const pdfBuffer = fs.readFileSync(filepath);
      const base64PDF = pdfBuffer.toString('base64');
      fs.unlinkSync(filepath);
      return base64PDF;
    } catch (error) {
      console.error('❌ Error generating base64 PDF:', error);
      throw error;
    }
  }
}

export default new PDFService();