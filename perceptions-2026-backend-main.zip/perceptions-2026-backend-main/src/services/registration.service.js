import Registration from '../models/Registration.js';
import Event from '../models/Event.js';

class RegistrationService {
  /**
   * Generate unique registration ID for an event
   * Format: EVT-001, EVT-002, etc.
   * @param {string} eventId - Event ID
   * @returns {Promise<string>} - Unique registration ID
   */
  async generateRegistrationId(eventId) {
    try {
      // Get the count of registrations for this event
      const count = await Registration.countDocuments({ eventId });
      
      // Generate ID with zero-padding
      const paddedNumber = String(count + 1).padStart(3, '0');
      const registrationId = `EVT-${paddedNumber}`;

      // Check if ID already exists (race condition safety)
      const exists = await Registration.findOne({ registrationId });
      
      if (exists) {
        // If exists, recursively try next number
        return this.generateRegistrationId(eventId);
      }

      return registrationId;
    } catch (error) {
      throw new Error(`Failed to generate registration ID: ${error.message}`);
    }
  }

  /**
   * Calculate total amount based on event and team size
   * @param {Object} event - Event object
   * @param {number} teamSize - Number of team members
   * @returns {number} - Total amount to be paid
   */
  calculateAmount(event, teamSize) {
    // Base fee per person
    const baseFee = event.registrationFee;
    
    // For solo events, charge base fee
    if (event.teamType === 'solo') {
      return baseFee;
    }

    // For team events, multiply by team size
    return baseFee * teamSize;
  }

  /**
   * Validate team size against event constraints
   * @param {Object} event - Event object
   * @param {number} teamSize - Requested team size
   * @returns {boolean} - Whether team size is valid
   */
  validateTeamSize(event, teamSize) {
    if (event.teamType === 'solo') {
      return teamSize === 1;
    }

    if (event.teamType === 'fixed') {
      return teamSize === event.minTeamSize;
    }

    if (event.teamType === 'flexible') {
      return teamSize >= event.minTeamSize && teamSize <= event.maxTeamSize;
    }

    return false;
  }

  /**
   * Check if event has available slots
   * @param {Object} event - Event object
   * @returns {boolean} - Whether event has available slots
   */
  hasAvailableSlots(event) {
    if (!event.maxParticipants) {
      return true; // No limit
    }

    return event.currentParticipants < event.maxParticipants;
  }

  /**
   * Increment participant count for event
   * @param {string} eventId - Event ID
   * @param {number} teamSize - Team size to add
   */
  /** Increment team count (1 team = 1 slot) */
  async incrementParticipantCount(eventId) {
    await Event.findByIdAndUpdate(
      eventId,
      { $inc: { currentParticipants: 1 } }
    );
  }

  /**
   * Get registration statistics
   * @returns {Promise<Object>} - Registration statistics
   */
  async getStatistics() {
    const total = await Registration.countDocuments();
    const pending = await Registration.countDocuments({ paymentStatus: 'Pending' });
    const underReview = await Registration.countDocuments({ paymentStatus: 'Under Review' });
    const confirmed = await Registration.countDocuments({ paymentStatus: 'Confirmed' });
    const rejected = await Registration.countDocuments({ paymentStatus: 'Rejected' });

    const totalRevenue = await Registration.aggregate([
      { $match: { paymentStatus: 'Confirmed' } },
      { $group: { _id: null, total: { $sum: '$amountPaid' } } },
    ]);

    return {
      total,
      pending,
      underReview,
      confirmed,
      rejected,
      totalRevenue: totalRevenue.length > 0 ? totalRevenue[0].total : 0,
    };
  }
}

export default new RegistrationService();
