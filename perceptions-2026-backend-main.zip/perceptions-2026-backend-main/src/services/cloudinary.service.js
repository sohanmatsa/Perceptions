import { v2 as cloudinary } from 'cloudinary';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

class CloudinaryService {
  /**
   * Upload payment screenshot to Cloudinary
   */
  async uploadPaymentScreenshot(filepath, registrationId) {
    try {
      console.log('📤 Uploading payment screenshot...');
      
      const result = await cloudinary.uploader.upload(filepath, {
        folder: 'fest/payments',
        public_id: `payment_${registrationId}_${Date.now()}`,
        resource_type: 'image',
      });

      console.log('✅ Payment screenshot uploaded');
      return result.secure_url;
    } catch (error) {
      console.error('❌ Error uploading payment screenshot:', error);
      throw new Error('Failed to upload payment screenshot');
    }
  }

  /**
   * Upload PDF receipt to Cloudinary
   */
  async uploadReceipt(filepath, registrationId) {
    try {
      console.log('📤 Uploading PDF receipt to Cloudinary...');
      console.log('📁 File path:', filepath);
      
      if (!fs.existsSync(filepath)) {
        throw new Error('PDF file does not exist: ' + filepath);
      }
      
      const stats = fs.statSync(filepath);
      console.log('📏 File size:', stats.size, 'bytes');
      
      if (stats.size === 0) {
        throw new Error('PDF file is empty');
      }
      
      const buffer = fs.readFileSync(filepath);
      const header = buffer.slice(0, 5).toString();
      
      if (!header.startsWith('%PDF-')) {
        throw new Error('File is not a valid PDF');
      }
      
      console.log('✅ PDF file is valid');
      
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const result = await cloudinary.uploader.upload(filepath, {
        folder: 'fest/receipts',
        public_id: `receipt_${registrationId}_${Date.now()}`,
        resource_type: 'raw',
        format: 'pdf',
        type: 'upload',
        invalidate: true,
      });

      console.log('✅ PDF uploaded successfully!');
      console.log('🔗 URL:', result.secure_url);
      
      return result.secure_url;
    } catch (error) {
      console.error('❌ Error uploading PDF to Cloudinary:', error);
      throw new Error('Failed to upload receipt to Cloudinary: ' + error.message);
    }
  }

  /**
   * ✅ Upload event logo to Cloudinary
   */
  async uploadEventLogo(filepath, eventName) {
    try {
      console.log('📤 Uploading event logo...');

      if (!fs.existsSync(filepath)) {
        throw new Error('Logo file does not exist: ' + filepath);
      }

      const safeName = eventName
        ? eventName.toLowerCase().replace(/[^a-z0-9]/g, '_').substring(0, 50)
        : 'event';

      const result = await cloudinary.uploader.upload(filepath, {
        folder: 'fest/event-logos',
        public_id: `logo_${safeName}_${Date.now()}`,
        resource_type: 'image',
        transformation: [
          { width: 500, height: 500, crop: 'fit' },
          { quality: 'auto', fetch_format: 'auto' },
        ],
      });

      console.log('✅ Event logo uploaded:', result.secure_url);
      return result.secure_url;
    } catch (error) {
      console.error('❌ Error uploading event logo:', error);
      throw new Error('Failed to upload event logo: ' + error.message);
    }
  }

  /**
   * Delete local file
   */
  async deleteLocalFile(filepath) {
    try {
      if (fs.existsSync(filepath)) {
        fs.unlinkSync(filepath);
        console.log('🗑️  Deleted local file:', filepath);
      }
    } catch (error) {
      console.error('⚠️  Could not delete local file:', filepath, error);
    }
  }

  /**
   * ✅ Delete file from Cloudinary (supports both naming conventions)
   * Called as deleteFile() in admin.controller.js
   */
  async deleteFile(publicId, resourceType = 'image') {
    try {
      const result = await cloudinary.uploader.destroy(publicId, {
        resource_type: resourceType,
      });
      console.log('🗑️  Deleted from Cloudinary:', publicId);
      return result;
    } catch (error) {
      console.error('❌ Error deleting from Cloudinary:', error);
      throw error;
    }
  }

  /**
   * Alias for deleteFile (for backwards compatibility)
   */
  async deleteFromCloudinary(publicId, resourceType = 'image') {
    return this.deleteFile(publicId, resourceType);
  }
}

export default new CloudinaryService();