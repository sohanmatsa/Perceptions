import express from 'express';
import multer from 'multer';
import { protect, authorize } from '../middleware/auth.js';
import {
  createEvent,
  updateEvent,
  deleteEvent,
  getAllRegistrationsAdmin,
  deleteRegistration,
  confirmPayment,
  getPendingPayments,
  getStatistics,
} from '../controllers/admin.controller.js';

const router = express.Router();

// ========== MULTER CONFIGURATION ==========
const upload = multer({ 
  dest: 'uploads/',
  limits: {
    fileSize: 2 * 1024 * 1024, // 2MB max
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG, and WEBP images are allowed'));
    }
  }
});
// =========================================

// All admin routes require authentication and admin role
router.use(protect);
router.use(authorize('admin', 'super_admin'));

// Event management
router.post('/events', upload.single('logo'), createEvent);  // ← ADD upload.single('logo')
router.put('/events/:eventId', upload.single('logo'), updateEvent);  // ← Optional: for edit
router.delete('/events/:eventId', deleteEvent);

// Registration management
router.get('/registrations', getAllRegistrationsAdmin);
router.delete('/registrations/:registrationId', deleteRegistration);

// Payment management
router.post('/confirm-payment', confirmPayment);
router.get('/pending-payments', getPendingPayments);

// Statistics
router.get('/statistics', getStatistics);

export default router;