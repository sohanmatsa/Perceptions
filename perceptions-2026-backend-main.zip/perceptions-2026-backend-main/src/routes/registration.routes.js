import express from 'express';
import {
  createRegistration,
  getRegistration,
  getAllRegistrations,
  downloadReceipt,
} from '../controllers/registration.controller.js';

const router = express.Router();

// Public routes
router.post('/', createRegistration);
router.get('/', getAllRegistrations);
router.get('/:registrationId', getRegistration);
router.get('/:registrationId/receipt', downloadReceipt);

export default router;
