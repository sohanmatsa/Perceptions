import express from 'express';
import upload, { handleMulterError } from '../middleware/upload.js';
import {
  uploadPayment,
  getPaymentStatus,
  getPaymentInstructions,
} from '../controllers/payment.controller.js';

const router = express.Router();

// Public routes
router.get('/instructions', getPaymentInstructions);
router.post('/upload', upload.single('paymentScreenshot'), handleMulterError, uploadPayment);
router.get('/:registrationId', getPaymentStatus);

export default router;
