import express from 'express';
import Registration from '../models/Registration.js';
import { asyncHandler, AppError } from '../middleware/error.js';

const router = express.Router();

/**
 * @desc    Download receipt PDF
 * @route   GET /api/receipts/:registrationId
 * @access  Public
 */
router.get('/:registrationId', asyncHandler(async (req, res, next) => {
  const { registrationId } = req.params;
  
  console.log('📥 Receipt download request for:', registrationId);
  
  // Find registration
  const registration = await Registration.findOne({ registrationId });
  
  if (!registration) {
    return next(new AppError('Registration not found', 404));
  }
  
  if (!registration.receiptPDF) {
    return next(new AppError('Receipt not available yet', 404));
  }
  
  try {
    // Convert base64 back to buffer
    const pdfBuffer = Buffer.from(registration.receiptPDF, 'base64');
    
    console.log('✅ Serving PDF, size:', pdfBuffer.length, 'bytes');
    
    // Set headers for PDF download
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="Receipt_${registrationId}.pdf"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.setHeader('Cache-Control', 'public, max-age=31536000');
    
    // Send PDF
    res.send(pdfBuffer);
    
  } catch (error) {
    console.error('❌ Error serving PDF:', error);
    return next(new AppError('Failed to download receipt', 500));
  }
}));

export default router;