import express from 'express';
import {
  getAllEvents,
  getEvent,
  getEventsByCategory,
} from '../controllers/event.controller.js';

const router = express.Router();

// Public routes
router.get('/', getAllEvents);
router.get('/category/:category', getEventsByCategory);
router.get('/:eventId', getEvent);

export default router;
