import express from 'express';
import { protect } from '../middleware/auth.js';
import {
  login,
  getMe,
  setupAdmin,
  logout,
} from '../controllers/auth.controller.js';

const router = express.Router();

// Public routes
router.post('/login', login);
router.post('/setup', setupAdmin);

// Protected routes
router.get('/me', protect, getMe);
router.post('/logout', protect, logout);

export default router;
