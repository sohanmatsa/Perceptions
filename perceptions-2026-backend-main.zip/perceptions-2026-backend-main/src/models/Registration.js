import mongoose from 'mongoose';

const teamMemberSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true,
  },
  phone: {
    type: String,
    required: [true, 'Phone number is required'],
    match: [/^[6-9]\d{9}$/, 'Please provide a valid 10-digit phone number starting with 6-9'],
  },
  collegeEmail: {
    type: String,
    required: [true, 'College email is required'],
    lowercase: true,
    trim: true,
  },
  collegeName: {
    type: String,
    required: [true, 'College name is required'],
    trim: true,
  },
  // Keep 'nad' for backward compatibility
  nad: {
    type: String,
    trim: true,
    default: null,
  },
});

const registrationSchema = new mongoose.Schema(
  {
    registrationId: {
      type: String,
      required: true,
      unique: true,
    },
    eventId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Event',
      required: true,
    },
    eventName: {
      type: String,
      required: true,
    },
    teamMembers: {
      type: [teamMemberSchema],
      required: true,
      validate: {
        validator: function (v) {
          return v && v.length > 0;
        },
        message: 'At least one team member is required',
      },
    },
    teamSize: {
      type: Number,
      required: true,
      min: 1,
    },
    amountPaid: {
      type: Number,
      required: true,
      min: 0,
    },
    paymentScreenshotUrl: {
      type: String,
      default: null,
    },
    utrNumber: {
      type: String,
      default: null,
    },
    remitterName: {
      type: String,
      default: null,
    },
    paymentStatus: {
      type: String,
      enum: ['Pending', 'Under Review', 'Confirmed', 'Rejected'],
      default: 'Pending',
    },

    // ✅ ADDED: confirmedBy - which admin confirmed/rejected the payment
    confirmedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Admin',
      default: null,
    },

    confirmedAt: {
      type: Date,
      default: null,
    },
    receiptUrl: {
      type: String,
      default: null,
    },
    receiptPDF: {
      type: String, // Base64 encoded PDF
      default: null,
    },
    primaryContact: {
      type: String,
    },
    adminNotes: {
      type: String,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// Virtual for primary contact (team lead)
registrationSchema.virtual('teamLead').get(function () {
  return this.teamMembers[0];
});

// Pre-save hook to set primary contact
registrationSchema.pre('save', function (next) {
  if (this.teamMembers && this.teamMembers.length > 0) {
    this.primaryContact = this.teamMembers[0].phone;
  }
  next();
});

// Indexes for better performance
registrationSchema.index({ registrationId: 1 });
registrationSchema.index({ eventId: 1, paymentStatus: 1 });
registrationSchema.index({ 'teamMembers.collegeEmail': 1 });
registrationSchema.index({ createdAt: -1 });

const Registration = mongoose.model('Registration', registrationSchema);

export default Registration;