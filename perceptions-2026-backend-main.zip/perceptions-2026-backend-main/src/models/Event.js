import mongoose from 'mongoose';

const eventSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Event name is required'],
      trim: true,
    },
    description: {
      type: String,
      required: [true, 'Event description is required'],
    },
    category: {
      type: String,
      required: [true, 'Event category is required'],
      enum: ['management', 'cultural', 'sports'],  // all lowercase
      lowercase: true,  // this now works correctly
    },
    date: {
      type: Date,
      required: [true, 'Event date is required'],
    },
    time: {
      type: String,
      required: [true, 'Event time is required'],
    },
    venue: {
      type: String,
      required: [true, 'Event venue is required'],
    },
    registrationFee: {
      type: Number,
      required: [true, 'Registration fee is required'],
      min: [0, 'Registration fee cannot be negative'],
    },
    prizePool: {
      type: String,
      default: null,
    },
    maxParticipants: {
      type: Number,
      default: null,
    },
    currentParticipants: {
      type: Number,
      default: 0,
    },
    teamType: {
      type: String,
      enum: ['solo', 'fixed', 'flexible'],
      default: 'solo',
    },
    minTeamSize: {
      type: Number,
      default: 1,
      min: 1,
    },
    maxTeamSize: {
      type: Number,
      default: 1,
      min: 1,
    },
    rules: {
      type: [String],
      default: [],
    },
    icon: {
      type: String,
      default: '🎯',
    },
    logoUrl: {
      type: String,
      default: null,
    },
    // ========== NEW: EVENT COORDINATOR FIELDS ==========
    coordinators: [{
      name: {
        type: String,
        required: true,
        trim: true,
      },
      role: {
        type: String,
        default: 'Coordinator',
        trim: true,
      },
      phone: {
        type: String,
        required: true,
        match: [/^[0-9]{10}$/, 'Please provide a valid 10-digit phone number'],
      },
      email: {
        type: String,
        trim: true,
        lowercase: true,
      },
    }],
    // Alternative: Single coordinator fields (if you prefer simple approach)
    primaryCoordinatorName: {
      type: String,
      trim: true,
    },
    primaryCoordinatorPhone: {
      type: String,
      match: [/^[0-9]{10}$/, 'Please provide a valid 10-digit phone number'],
    },
    secondaryCoordinatorName: {
      type: String,
      trim: true,
    },
    secondaryCoordinatorPhone: {
      type: String,
      match: [/^[0-9]{10}$/, 'Please provide a valid 10-digit phone number'],
    },
    coordinatorEmail: {
      type: String,
      trim: true,
      lowercase: true,
    },
    // ===================================================
    isActive: {
      type: Boolean,
      default: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Admin',
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for better query performance
eventSchema.index({ category: 1, isActive: 1 });
eventSchema.index({ date: 1 });
eventSchema.index({ createdAt: -1 });

const Event = mongoose.model('Event', eventSchema);

export default Event;