// ==================== LOAD ENV FIRST (CRITICAL) ====================
import dotenv from 'dotenv';
dotenv.config();
// ==================================================================

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import rateLimit from 'express-rate-limit';

import connectDB from './config/database.js';
import { notFound, errorHandler } from './middleware/error.js';

// ==================== IMPORT ROUTES ====================
import authRoutes from './routes/auth.routes.js';
import eventRoutes from './routes/event.routes.js';
import registrationRoutes from './routes/registration.routes.js';
import receiptRoutes from './routes/receipt.routes.js';
import paymentRoutes from './routes/payment.routes.js';
import adminRoutes from './routes/admin.routes.js';
// ======================================================

// Create Express app
const app = express();

// Connect to database
connectDB();

// Security middleware
app.use(helmet());

// ==================== CORS CONFIGURATION ====================
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'https://perceptions-2026-frontend.vercel.app',
  'https://perceptions.co.in',
  'https://www.perceptions.co.in',
  process.env.FRONTEND_URL,
].filter(Boolean); // Remove any undefined/null values

const corsOptions = {
  origin: function (origin, callback) {
    // Allow requests with no origin (Postman, mobile apps, server-to-server)
    if (!origin) return callback(null, true);

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.log('❌ CORS blocked for origin:', origin);
      callback(new Error(`CORS policy: Origin ${origin} not allowed`));
    }
  },
  credentials: true,
  optionsSuccessStatus: 200,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: [
    'Content-Type',
    'Authorization',
    'X-Requested-With',
    'Accept',
    'Origin',
  ],
};

app.use(cors(corsOptions));

// Handle preflight OPTIONS requests for ALL routes
app.options('*', cors(corsOptions));
// ===========================================================

// Body parser middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Compression middleware
app.use(compression());

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
});

app.use('/api/', limiter);

// Health check route
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is running',
    environment: process.env.NODE_ENV,
    timestamp: new Date().toISOString(),
  });
});

// ==================== API ROUTES ====================
app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/registrations', registrationRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/receipts', receiptRoutes);
// ====================================================

// Root route
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Welcome to TechFusion 2026 API',
    version: '1.0.0',
    endpoints: {
      health: '/health',
      auth: '/api/auth',
      events: '/api/events',
      registrations: '/api/registrations',
      payments: '/api/payments',
      admin: '/api/admin',
    },
  });
});

// Error handling (MUST BE AFTER ALL ROUTES)
app.use(notFound);
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🎉 SANGAMA PERCEPTIONS 2026 Backend Server             ║
║                                                           ║
║   Environment: ${process.env.NODE_ENV || 'development'}   ║
║   Port: ${PORT}                                           ║
║   URL: http://localhost:${PORT}                           ║
║                                                           ║
║   API Documentation: http://localhost:${PORT}/            ║
║   Health Check: http://localhost:${PORT}/health           ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);

  console.log('\n✅ Allowed CORS Origins:');
  allowedOrigins.forEach(origin => console.log(`   - ${origin}`));

  console.log('\n📍 Registered API Routes:');
  console.log('   POST   /api/auth/login');
  console.log('   POST   /api/auth/setup');
  console.log('   GET    /api/auth/me');
  console.log('   GET    /api/events');
  console.log('   GET    /api/events/:eventId');
  console.log('   POST   /api/registrations');
  console.log('   GET    /api/registrations/:registrationId');
  console.log('   POST   /api/payments/upload');
  console.log('   GET    /api/payments/:registrationId');
  console.log('   POST   /api/admin/confirm-payment');
  console.log('   GET    /api/admin/pending-payments');
  console.log('   GET    /api/admin/statistics');
  console.log('   POST   /api/admin/events');
  console.log('   PUT    /api/admin/events/:eventId');
  console.log('   DELETE /api/admin/events/:eventId\n');
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err.message);
  server.close(() => process.exit(1));
});

// Handle SIGTERM
process.on('SIGTERM', () => {
  console.log('👋 SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('✅ Process terminated');
  });
});

export default app;