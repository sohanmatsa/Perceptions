import Joi from 'joi';

// Team member validation schema
const teamMemberSchema = Joi.object({
  name: Joi.string().trim().min(2).max(100).required().messages({
    'string.empty': 'Team member name is required',
    'string.min': 'Name must be at least 2 characters',
    'string.max': 'Name cannot exceed 100 characters',
  }),
  phone: Joi.string().pattern(/^[6-9]\d{9}$/).required().messages({
    'string.pattern.base': 'Please enter a valid 10-digit phone number starting with 6-9',
    'string.empty': 'Phone number is required',
  }),
  collegeEmail: Joi.string().email().lowercase().trim().required().messages({
    'string.email': 'Please enter a valid email address',
    'string.empty': 'College email is required',
  }),
  collegeName: Joi.string().trim().min(2).max(200).required().messages({
    'string.empty': 'College name is required',
    'string.min': 'College name must be at least 2 characters',
  }),
  nad: Joi.string().trim().allow('', null).optional(),
});

// Registration validation schema
export const registrationValidation = Joi.object({
  eventId: Joi.string().hex().length(24).required().messages({
    'string.empty': 'Event ID is required',
    'string.hex': 'Invalid event ID format',
    'string.length': 'Invalid event ID format',
  }),
  teamMembers: Joi.array().items(teamMemberSchema).min(1).required().messages({
    'array.min': 'At least one team member is required',
    'array.base': 'Team members must be an array',
  }),
});

// Payment upload validation schema
export const paymentUploadValidation = Joi.object({
  registrationId: Joi.string().required().messages({
    'string.empty': 'Registration ID is required',
  }),
  remitterName: Joi.string().trim().min(2).max(100).required().messages({
    'string.empty': 'Remitter name is required',
    'string.min': 'Remitter name must be at least 2 characters',
  }),
  utrNumber: Joi.string().trim().min(5).max(30).required().messages({
    'string.empty': 'UTR number is required',
    'string.min': 'UTR number must be at least 5 characters',
  }),
});

// Payment confirmation validation schema
export const paymentConfirmationValidation = Joi.object({
  registrationId: Joi.string().required().messages({
    'string.empty': 'Registration ID is required',
  }),
  status: Joi.string().valid('Confirmed', 'Rejected').required().messages({
    'any.only': 'Status must be either Confirmed or Rejected',
    'string.empty': 'Payment status is required',
  }),
  adminNotes: Joi.string().trim().allow('', null).optional(),
});

// ✅ EVENT CREATION VALIDATION - synced with AdminCreateEvent.jsx
export const eventValidation = Joi.object({
  // Core fields
  name: Joi.string().trim().min(3).max(200).required(),
  description: Joi.string().trim().min(10).max(1000).required(),
  category: Joi.string().valid('management', 'cultural', 'sports').required(),
  icon: Joi.string().allow('', null).default('🎯'),

  // Date & Location
  date: Joi.date().iso().required(),
  time: Joi.string().trim().required(),
  venue: Joi.string().trim().required(),

  // Fees & Prize
  registrationFee: Joi.number().min(0).required(),
  prizePool: Joi.string().trim().allow('', null).default('TBA'),

  // Participants
  maxParticipants: Joi.number().integer().min(1).allow('', null).optional(),

  // Team settings
  teamType: Joi.string().valid('solo', 'fixed', 'flexible').required(),
  minTeamSize: Joi.number().integer().min(1).default(1),
  maxTeamSize: Joi.number().integer().min(1).default(1),

  // Rules
  rules: Joi.array().items(Joi.string().trim()).default([]),

  // Status
  isActive: Joi.boolean().default(true),

  // Primary Coordinator (required)
  primaryCoordinatorName: Joi.string().trim().min(2).max(100).required().messages({
    'string.empty': 'Primary coordinator name is required',
  }),
  primaryCoordinatorPhone: Joi.string().pattern(/^[0-9]{10}$/).required().messages({
    'string.empty': 'Primary coordinator phone is required',
    'string.pattern.base': 'Please provide a valid 10-digit phone number',
  }),

  // Secondary Coordinator (optional)
  secondaryCoordinatorName: Joi.string().trim().allow('', null).optional(),
  secondaryCoordinatorPhone: Joi.string().pattern(/^[0-9]{10}$/).allow('', null).optional().messages({
    'string.pattern.base': 'Please provide a valid 10-digit phone number',
  }),

  // Coordinator Email (required)
  coordinatorEmail: Joi.string().email().lowercase().trim().required().messages({
    'string.email': 'Please enter a valid coordinator email address',
    'string.empty': 'Coordinator email is required',
  }),
});

// Admin login validation schema
export const adminLoginValidation = Joi.object({
  email: Joi.string().email().lowercase().trim().required().messages({
    'string.email': 'Please enter a valid email address',
    'string.empty': 'Email is required',
  }),
  password: Joi.string().min(6).required().messages({
    'string.min': 'Password must be at least 6 characters',
    'string.empty': 'Password is required',
  }),
});