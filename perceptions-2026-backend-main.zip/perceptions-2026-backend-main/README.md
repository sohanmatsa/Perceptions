# TechFusion 2026 - Backend API

Complete production-ready backend for college fest event registration system with payment verification and receipt generation.

## 🚀 Features

### Core Functionality
- ✅ **Event Registration** - Solo, fixed team, and flexible team size support
- ✅ **Payment Upload** - Screenshot upload to Cloudinary
- ✅ **Payment Verification** - Admin-controlled payment confirmation
- ✅ **Receipt Generation** - Auto-generated PDF receipts
- ✅ **File Storage** - Cloudinary integration (no files in MongoDB)
- ✅ **Admin Dashboard** - Statistics, pending payments, event management
- ✅ **JWT Authentication** - Secure admin-only routes

### Security Features
- ✅ Helmet.js for security headers
- ✅ Rate limiting (100 requests per 15 minutes)
- ✅ Input validation with Joi
- ✅ JWT token authentication
- ✅ Bcrypt password hashing
- ✅ CORS protection
- ✅ File type and size validation

## 📁 Project Structure

```
fest-backend/
├── src/
│   ├── config/
│   │   ├── database.js          # MongoDB connection
│   │   └── cloudinary.js        # Cloudinary configuration
│   ├── controllers/
│   │   ├── auth.controller.js   # Admin authentication
│   │   ├── event.controller.js  # Event management
│   │   ├── registration.controller.js
│   │   ├── payment.controller.js
│   │   └── admin.controller.js  # Admin-only operations
│   ├── middleware/
│   │   ├── auth.js              # JWT authentication
│   │   ├── upload.js            # Multer file upload
│   │   └── error.js             # Error handling
│   ├── models/
│   │   ├── Admin.js             # Admin schema
│   │   ├── Event.js             # Event schema
│   │   └── Registration.js      # Registration schema
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── event.routes.js
│   │   ├── registration.routes.js
│   │   ├── payment.routes.js
│   │   └── admin.routes.js
│   ├── services/
│   │   ├── cloudinary.service.js  # File upload service
│   │   ├── pdf.service.js         # PDF generation
│   │   └── registration.service.js # Business logic
│   ├── utils/
│   │   └── validation.js          # Joi validation schemas
│   └── server.js                  # Main application
├── uploads/                        # Temporary file storage
├── .env.example                    # Environment variables template
├── package.json
└── README.md
```

## 🛠️ Installation

### Prerequisites
- Node.js 16+ installed
- MongoDB Atlas account
- Cloudinary account

### Step 1: Clone and Install

```bash
# Navigate to backend directory
cd fest-backend

# Install dependencies
npm install
```

### Step 2: Environment Setup

Create `.env` file from the template:

```bash
cp .env.example .env
```

Update `.env` with your actual credentials:

```env
# Server
PORT=5000
NODE_ENV=development

# MongoDB Atlas
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/festdb

# Cloudinary
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret

# JWT
JWT_SECRET=your_super_secret_key_change_in_production
JWT_EXPIRE=7d

# Frontend
FRONTEND_URL=http://localhost:3000
```

### Step 3: Setup Admin Account

Start the server:

```bash
npm run dev
```

Create the first admin account:

```bash
POST http://localhost:5000/api/auth/setup
Content-Type: application/json

{
  "name": "Super Admin",
  "email": "admin@fest.edu",
  "password": "securepassword123"
}
```

## 🎯 API Endpoints

### Public Routes

#### Events
```
GET    /api/events                    # Get all active events
GET    /api/events/:eventId           # Get single event
GET    /api/events/category/:category # Get events by category
```

#### Registration
```
POST   /api/registrations             # Create new registration
GET    /api/registrations             # Get all registrations
GET    /api/registrations/:id         # Get registration by ID
GET    /api/registrations/:id/receipt # Download receipt
```

#### Payment
```
GET    /api/payments/instructions     # Get payment instructions
POST   /api/payments/upload           # Upload payment screenshot
GET    /api/payments/:registrationId  # Get payment status
```

### Admin Routes (Require JWT Token)

#### Authentication
```
POST   /api/auth/login                # Admin login
GET    /api/auth/me                   # Get current admin
POST   /api/auth/logout               # Logout
```

#### Admin Operations
```
POST   /api/admin/confirm-payment     # Confirm/reject payment
GET    /api/admin/pending-payments    # Get pending payments
GET    /api/admin/statistics          # Get statistics
GET    /api/admin/registrations       # Get all registrations (admin)

POST   /api/admin/events              # Create event
PUT    /api/admin/events/:id          # Update event
DELETE /api/admin/events/:id          # Delete event
```

## 📝 API Usage Examples

### 1. Create Registration

```javascript
POST /api/registrations
Content-Type: application/json

{
  "eventId": "65abc123def456789",
  "teamMembers": [
    {
      "name": "John Doe",
      "phone": "9876543210",
      "collegeEmail": "john@college.edu",
      "collegeName": "ABC College",
      "nad": "NAD123" // optional
    }
  ]
}

Response:
{
  "success": true,
  "message": "Registration created successfully",
  "data": {
    "registrationId": "EVT-001",
    "eventName": "Coding Marathon",
    "teamSize": 1,
    "amountPaid": 500,
    "paymentStatus": "Pending"
  }
}
```

### 2. Upload Payment Screenshot

```javascript
POST /api/payments/upload
Content-Type: multipart/form-data

Form Data:
- paymentScreenshot: [file]
- registrationId: "EVT-001"
- remitterName: "John Doe"
- utrNumber: "UTR123456789"

Response:
{
  "success": true,
  "message": "Payment screenshot uploaded successfully",
  "data": {
    "registrationId": "EVT-001",
    "paymentStatus": "Under Review",
    "screenshotUrl": "https://res.cloudinary.com/..."
  }
}
```

### 3. Admin: Confirm Payment

```javascript
POST /api/admin/confirm-payment
Authorization: Bearer <JWT_TOKEN>
Content-Type: application/json

{
  "registrationId": "EVT-001",
  "status": "Confirmed",
  "adminNotes": "Payment verified"
}

Response:
{
  "success": true,
  "message": "Payment confirmed and receipt generated",
  "data": {
    "registrationId": "EVT-001",
    "paymentStatus": "Confirmed",
    "receiptUrl": "https://res.cloudinary.com/.../receipt.pdf"
  }
}
```

### 4. Admin Login

```javascript
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@fest.edu",
  "password": "securepassword123"
}

Response:
{
  "success": true,
  "message": "Login successful",
  "data": {
    "admin": {
      "id": "65abc...",
      "name": "Super Admin",
      "email": "admin@fest.edu",
      "role": "super_admin"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

## 🗄️ Database Schema

### Registration Model
```javascript
{
  registrationId: "EVT-001",        // Unique auto-generated
  eventId: ObjectId,                // Reference to Event
  eventName: "Coding Marathon",
  teamMembers: [
    {
      name: "John Doe",
      phone: "9876543210",
      collegeEmail: "john@college.edu",
      collegeName: "ABC College",
      nad: "NAD123"
    }
  ],
  teamSize: 1,
  amountPaid: 500,
  paymentStatus: "Pending" | "Under Review" | "Confirmed" | "Rejected",
  paymentScreenshotUrl: "https://...",  // Cloudinary URL
  receiptUrl: "https://...",            // Cloudinary URL
  utrNumber: "UTR123456789",
  remitterName: "John Doe",
  adminNotes: "Payment verified",
  confirmedBy: ObjectId,                // Admin who confirmed
  confirmedAt: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### Event Model
```javascript
{
  name: "Coding Marathon",
  category: "technical" | "cultural" | "business" | "sports" | "arts",
  description: "24-hour hackathon...",
  teamType: "solo" | "fixed" | "flexible",
  minTeamSize: 1,
  maxTeamSize: 4,
  registrationFee: 500,
  venue: "Computer Lab A",
  date: Date,
  time: "9:00 AM",
  isActive: true,
  maxParticipants: 100,
  currentParticipants: 0
}
```

## 🔒 Security Best Practices

1. **Never commit `.env` file** - Contains sensitive credentials
2. **Use strong JWT secret** - At least 32 characters
3. **Enable HTTPS in production** - Use SSL/TLS certificates
4. **Set proper CORS origins** - Restrict to your frontend domain
5. **Regular security updates** - Keep dependencies updated
6. **Rate limiting** - Already configured (100 req/15min)
7. **Input validation** - All inputs validated with Joi
8. **File type validation** - Only images allowed for payments

## 📊 Admin Dashboard Features

- View all registrations
- Filter by event, payment status
- Search by registration ID or email
- View pending payments
- Confirm/reject payments
- Generate receipts automatically
- View statistics (revenue, registrations, etc.)
- Event management (CRUD operations)

## 🚀 Deployment

### Option 1: Heroku

```bash
# Install Heroku CLI
heroku login

# Create app
heroku create fest-backend

# Set environment variables
heroku config:set MONGODB_URI=your_uri
heroku config:set CLOUDINARY_CLOUD_NAME=your_name
# ... set all other env variables

# Deploy
git push heroku main
```

### Option 2: Render

1. Connect GitHub repository
2. Set environment variables in dashboard
3. Deploy automatically

### Option 3: VPS (Digital Ocean, AWS, etc.)

```bash
# SSH into server
ssh user@your-server-ip

# Clone repository
git clone your-repo-url
cd fest-backend

# Install dependencies
npm install --production

# Setup PM2
npm install -g pm2
pm2 start src/server.js --name fest-api
pm2 save
pm2 startup
```

## 🧪 Testing

```bash
# Health check
GET http://localhost:5000/health

# Test with Postman
Import the Postman collection (create one from API docs)

# Test file upload
Use form-data in Postman for /api/payments/upload
```

## 📈 Monitoring

- Check logs: `pm2 logs fest-api`
- View stats: `GET /api/admin/statistics`
- Database monitoring: MongoDB Atlas dashboard
- File storage: Cloudinary dashboard

## 🐛 Common Issues & Solutions

### Issue: MongoDB connection failed
**Solution**: Check MONGODB_URI in .env, ensure IP whitelisting in Atlas

### Issue: Cloudinary upload failed
**Solution**: Verify API credentials, check file size limits

### Issue: JWT token expired
**Solution**: Login again to get new token

### Issue: File upload error
**Solution**: Check file type (only JPEG/PNG), max size 5MB

## 📞 Support

For issues or questions:
- Create an issue on GitHub
- Email: tech@techfusion.edu

## 📄 License

MIT License - See LICENSE file for details

---

**Built with ❤️ for TechFusion 2026**
