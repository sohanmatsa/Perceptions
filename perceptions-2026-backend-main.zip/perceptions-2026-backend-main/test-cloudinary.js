import dotenv from 'dotenv';
import { v2 as cloudinary } from 'cloudinary';

// Load environment variables FIRST
dotenv.config();

console.log('🔍 Testing Cloudinary Configuration...\n');

// Check if env variables are loaded
const cloudName = process.env.CLOUDINARY_CLOUD_NAME;
const apiKey = process.env.CLOUDINARY_API_KEY;
const apiSecret = process.env.CLOUDINARY_API_SECRET;

console.log('Environment Variables:');
console.log('Cloud Name:', cloudName || '❌ NOT SET');
console.log('API Key:', apiKey || '❌ NOT SET');
console.log('API Secret:', apiSecret ? `***${apiSecret.slice(-4)}` : '❌ NOT SET');

if (!cloudName || !apiKey || !apiSecret) {
  console.log('\n❌ ERROR: Missing Cloudinary credentials!');
  process.exit(1);
}

// Configure Cloudinary
cloudinary.config({
  cloud_name: cloudName,
  api_key: apiKey,
  api_secret: apiSecret,
  secure: true
});

console.log('\n📡 Testing connection...\n');

// Test connection
cloudinary.api.ping()
  .then(result => {
    console.log('✅ SUCCESS! Cloudinary working!');
    console.log('Status:', result.status);
  })
  .catch(error => {
    console.log('❌ FAILED!');
    console.log('Error:', error.message);
  });